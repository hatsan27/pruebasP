# Prototipo web estático · Supervisión Escolar 072

Proyecto demostrativo desarrollado con React + Vite para la actividad **N.º 4: Diseño de interfaz y navegación** de la residencia profesional.

## Alcance

Se incluyen **cinco pantallas representativas** de las definidas en el Anexo 3:

| Clave del Anexo 3 | Pantalla incluida | Ruta |
| --- | --- | --- |
| P-01 | Inicio de sesión (simulado) | `#/acceso` |
| P-02 | Panel principal | `#/panel` |
| P-03 | Avisos | `#/avisos` |
| P-05 | Solicitudes | `#/solicitudes` |
| P-07 | Carga y revisión de evidencias (maqueta) | `#/evidencias` |

No se incluyen P-04, P-06, P-08 y P-09, ni pantallas adicionales. El prototipo muestra la navegación entre secciones, una vista de perfil simulada y datos ficticios.

**No hay autenticación, Firebase, base de datos, permisos reales, registro, recepción de archivos ni envío de formularios.** La pantalla de acceso es de demostración: sus campos no se guardan ni se transmiten. El filtro de solicitudes funciona exclusivamente en memoria dentro de la página.

## Ejecutar localmente

Requisitos: Node.js y npm.

```bash
npm install
npm run dev
```

Abre en el navegador la dirección que indique la terminal (habitualmente `http://localhost:5173`).

## Preparar la publicación

```bash
npm run build
```

La versión publicable se genera en la carpeta `dist/`.

## Publicar en GitHub y Netlify

1. Sube a tu repositorio de GitHub los archivos y carpetas de este proyecto. No subas `node_modules/` ni `dist/`.
2. En Netlify selecciona **Add new project → Import an existing project** y conecta el repositorio de GitHub.
3. Revisa estos parámetros (también están definidos en `netlify.toml`):
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Inicia el despliegue. La URL pública mostrará el prototipo estático.

Se utiliza navegación con rutas `#/...` para que el prototipo pueda abrirse desde cualquier hosting estático sin un backend.

## Evidencias sugeridas para el Anexo 3

- Captura de pantalla de P-01: inicio de sesión.
- Captura de pantalla de P-02: panel principal con vista de directora.
- Captura de pantalla de P-03: avisos.
- Captura de pantalla de P-05: solicitudes.
- Captura de pantalla de P-07: diseño de recepción de evidencias.
- Captura opcional de la misma pantalla en ancho móvil para demostrar diseño responsivo.
- URL del prototipo desplegado en Netlify y enlace al repositorio (una vez publicados).

Redacción propuesta para documentar el alcance real:

> Se desarrolló un prototipo navegable de cinco interfaces web representativas mediante React y CSS. Las pantallas permiten revisar la distribución de elementos, la jerarquía visual, la adaptación a dispositivos y la navegación entre módulos. El prototipo utiliza datos ficticios y no incluye todavía persistencia, autenticación ni carga real de documentos. Su finalidad es apoyar la validación preliminar del diseño antes de integrar los servicios de Firebase.

## Correspondencia con los anexos existentes

- **Anexo 2**: conserva los requerimientos funcionales y perfiles definidos.
- **Anexo 3**: constituye la base de las cinco pantallas seleccionadas para el prototipo.
- **Anexo 4**: mantiene el diseño técnico preliminar para una futura integración; no se implementa aún.

Este trabajo corresponde al **diseño de interfaz y navegación** y no debe presentarse como un sistema terminado o integrado a Firebase.
