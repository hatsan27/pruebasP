import { useEffect, useState } from 'react';

// Prototipo navegable. Todos los datos son ficticios y permanecen en el navegador.
const perfiles = {
  directora: { nombre: 'Directora', descripcion: 'Consulta de avisos, solicitudes y entregas' },
  supervisora: { nombre: 'Supervisora', descripcion: 'Vista general y revisión de información' },
  administrativa: { nombre: 'Administrativa', descripcion: 'Organización y seguimiento documental' },
};

const avisos = [
  { id: 'A-001', tipo: 'Comunicado', titulo: 'Reunión de coordinación', fecha: '14 oct 2026', texto: 'Información general sobre la próxima reunión de trabajo de la zona escolar.', publico: 'Todos los planteles' },
  { id: 'A-002', tipo: 'Recordatorio', titulo: 'Actualización de documentos', fecha: '10 oct 2026', texto: 'Recordatorio de consultar los formatos vigentes antes de realizar una entrega.', publico: 'Todos los planteles' },
  { id: 'A-003', tipo: 'Aviso general', titulo: 'Periodo de recepción de información', fecha: '07 oct 2026', texto: 'Se encuentra disponible una solicitud de ejemplo para revisar el flujo de entrega.', publico: 'Planteles seleccionados' },
];

const solicitudes = [
  { id: 'SOL-001', titulo: 'Planeación mensual', detalle: 'Documento de planeación correspondiente al periodo.', vence: '20 oct 2026', estado: 'Pendiente', area: 'Administración' },
  { id: 'SOL-002', titulo: 'Informe de actividades', detalle: 'Entrega de un informe breve en formato PDF.', vence: '24 oct 2026', estado: 'Entregado', area: 'Supervisión' },
  { id: 'SOL-003', titulo: 'Actualización de datos de plantel', detalle: 'Revisión de información general y registro administrativo.', vence: '28 oct 2026', estado: 'Corrección', area: 'Administración' },
  { id: 'SOL-004', titulo: 'Comprobante de reunión', detalle: 'Archivo digital de la evidencia correspondiente.', vence: '30 oct 2026', estado: 'Aceptado', area: 'Supervisión' },
];

function Icon({ name, size = 20, strokeWidth = 1.8 }) {
  const paths = {
    school: <><path d="m3 10 9-6 9 6"/><path d="M5 9v11h14V9M9 20v-7h6v7M3 20h18"/></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></>,
    list: <><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></>,
    file: <><path d="M7 3h7l5 5v13H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    down: <path d="m6 9 6 6 6-6"/>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18"/></>,
    upload: <><path d="M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4"/></>,
    check: <path d="m4 12 5 5L20 6"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M5 21a7 7 0 0 1 14 0"/></>,
    logout: <><path d="M9 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4M15 8l4 4-4 4M9 12h10"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></>,
    info: <><circle cx="12" cy="12" r="10"/><path d="M12 11v6M12 7h.01"/></>,
    eye: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="3"/></>,
    shield: <><path d="M12 3 4 6v6c0 5 3.2 8 8 10 4.8-2 8-5 8-10V6l-8-3Z"/><path d="m9 12 2 2 4-4"/></>,
    menu: <path d="M4 6h16M4 12h16M4 18h16"/>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 7 9-7"/></>,
    folder: <><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] || paths.file}</svg>;
}

function getCurrentRoute() {
  const route = window.location.hash.replace(/^#\/?/, '').split('?')[0];
  return ['acceso','panel','avisos','solicitudes','evidencias'].includes(route) ? route : 'acceso';
}

function goTo(route) {
  window.location.hash = `/${route}`;
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function Brand({ inverse = false, small = false }) {
  return <div className={`brand ${inverse ? 'brand-inverse' : ''}`}>
    <div className={`brand-symbol ${small ? 'brand-symbol-small' : ''}`}><Icon name="school" size={small ? 21 : 26} /></div>
    <div><strong>Supervisión Escolar 072</strong><span>Educación Preescolar · Zona 072</span></div>
  </div>;
}

function DemoNotice({ compact = false }) {
  return <div className={`demo-notice ${compact ? 'demo-notice-compact' : ''}`}><Icon name="info" size={17}/><span><strong>Prototipo estático.</strong> Contenido ficticio para pruebas de interfaz y navegación; no se guardan datos.</span></div>;
}

function Status({ estado }) {
  const classMap = { Pendiente:'status-pendiente', Entregado:'status-entregado', Corrección:'status-correccion', Aceptado:'status-aceptado' };
  return <span className={`status ${classMap[estado] || ''}`}><span className="status-dot" />{estado}</span>;
}

function Heading({ eyebrow, title, description, action }) {
  return <header className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action && <div className="page-heading-action">{action}</div>}</header>;
}

function LoginPage({ rol, setRol }) {
  const [correo,setCorreo] = useState('');
  const [clave,setClave] = useState('');
  const [showPassword,setShowPassword] = useState(false);
  function enterDemo(e) { e.preventDefault(); goTo('panel'); }
  return <div className="login-page">
    <section className="login-intro">
      <div className="login-intro-inner"><Brand inverse />
        <div className="login-main-copy"><span className="login-kicker">PLATAFORMA DE GESTIÓN ADMINISTRATIVA</span><h1>Un espacio para organizar la información escolar.</h1><p>Propuesta visual para centralizar avisos, dar seguimiento a solicitudes y consultar evidencias en la Supervisión Escolar 072.</p>
          <div className="login-tag"><Icon name="shield" size={18} /> Diseño preliminar de residencia profesional</div>
        </div><div className="login-intro-foot">Huetamo, Michoacán · Prototipo de interfaz · 2026</div>
      </div>
      <div className="login-pattern" aria-hidden="true"><div/><div/><div/></div>
    </section>
    <section className="login-form-section"><div className="login-form-wrap"><div className="mobile-brand"><Brand /></div>
      <div className="login-form-header"><div className="form-icon"><Icon name="user" size={23}/></div><div className="eyebrow">ACCESO DE DEMOSTRACIÓN</div><h2>Bienvenida a la plataforma</h2><p>Explora la propuesta de interfaz sin necesidad de crear una cuenta.</p></div>
      <form className="login-form" onSubmit={enterDemo}>
        <label htmlFor="correo">Correo electrónico <span className="field-suffix">(simulado)</span></label><div className="input-icon-wrap"><Icon name="mail" size={18}/><input id="correo" type="email" autoComplete="off" value={correo} onChange={e=>setCorreo(e.target.value)} placeholder="usuario@ejemplo.com" /></div>
        <label htmlFor="clave">Contraseña <span className="field-suffix">(simulada)</span></label><div className="input-icon-wrap"><Icon name="shield" size={18}/><input id="clave" type={showPassword?'text':'password'} autoComplete="off" value={clave} onChange={e=>setClave(e.target.value)} placeholder="••••••••" /><button type="button" className="input-aux" onClick={()=>setShowPassword(v=>!v)} aria-label={showPassword?'Ocultar contraseña':'Mostrar contraseña'}><Icon name="eye" size={18}/></button></div>
        <label htmlFor="rol">Vista que deseas explorar</label><select id="rol" value={rol} onChange={e=>setRol(e.target.value)}>{Object.entries(perfiles).map(([key, value])=><option key={key} value={key}>{value.nombre}</option>)}</select>
        <button className="btn btn-primary login-submit" type="submit">Entrar a la demostración <Icon name="arrow" size={19}/></button>
      </form>
      <DemoNotice compact />
      <p className="login-footnote">Esta pantalla no autentica usuarios. Los campos son visuales y no se transmiten ni almacenan.</p>
    </div></section>
  </div>;
}

const nav = [{ruta:'panel',icon:'grid',texto:'Panel principal'},{ruta:'avisos',icon:'bell',texto:'Avisos'},{ruta:'solicitudes',icon:'list',texto:'Solicitudes'},{ruta:'evidencias',icon:'file',texto:'Evidencias'}];

function AppShell({ route, rol, setRol, children }) {
  const [menuOpen,setMenuOpen] = useState(false);
  useEffect(()=>setMenuOpen(false),[route]);
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen?'sidebar-open':''}`}>
      <div className="sidebar-brand"><Brand inverse small /></div>
      <div className="sidebar-section-title">NAVEGACIÓN</div>
      <nav aria-label="Menú principal">{nav.map(item=><a key={item.ruta} href={`#/${item.ruta}`} className={`nav-link ${route===item.ruta?'active':''}`} aria-current={route===item.ruta?'page':undefined}><Icon name={item.icon} size={19}/><span>{item.texto}</span>{route===item.ruta && <span className="nav-active-mark" />}</a>)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-bottom"><div className="sidebar-mini"><span className="sidebar-mini-icon"><Icon name="info" size={17}/></span><span>Versión de demostración<br/><small>Sin conexión a base de datos</small></span></div><button className="sidebar-exit" onClick={()=>goTo('acceso')}><Icon name="logout" size={18}/> Volver al acceso</button></div>
    </aside>
    {menuOpen && <button className="mobile-backdrop" aria-label="Cerrar menú" onClick={()=>setMenuOpen(false)} />}
    <div className="app-content"><div className="topbar"><div className="topbar-start"><button className="hamburger" aria-label="Abrir menú" onClick={()=>setMenuOpen(v=>!v)}><Icon name="menu" size={22}/></button><span className="topbar-location"><span className="topbar-dot"/> Zona Escolar 072 <span className="topbar-divider">/</span> Prototipo web</span></div><div className="topbar-actions"><label htmlFor="select-rol" className="role-label">Vista de prueba</label><select id="select-rol" className="role-select" value={rol} onChange={e=>setRol(e.target.value)}>{Object.entries(perfiles).map(([key,value])=><option key={key} value={key}>{value.nombre}</option>)}</select><div className="avatar" title={perfiles[rol].nombre}>{perfiles[rol].nombre.slice(0,1)}</div></div></div>
      <div className="mobile-nav" aria-label="Secciones de la plataforma">{nav.map(item=><a key={item.ruta} className={`mobile-nav-link ${route===item.ruta?'active':''}`} href={`#/${item.ruta}`}>{item.texto}</a>)}</div>
      <main className="main-content">{children}<footer className="site-footer"><span>Supervisión Escolar 072 · Propuesta de interfaz</span><span>Residencia profesional · 2026</span></footer></main>
    </div>
  </div>;
}

function StatCard({ icon, number, label, foot }) {
  return <div className="stat-card"><div className="stat-top"><span className="stat-icon"><Icon name={icon} size={21}/></span><Icon name="chevron" size={17}/></div><div className="stat-value">{number}</div><div className="stat-label">{label}</div><div className="stat-foot">{foot}</div></div>;
}

function Dashboard({ rol }) {
  const isDirectora = rol==='directora';
  const nombre = perfiles[rol].nombre;
  return <>
    <Heading eyebrow="VISTA GENERAL" title={`Panel principal · ${nombre}`} description={`Una vista organizada para ${isDirectora?'consultar la información y las actividades asignadas al plantel':'consultar la información y el seguimiento administrativo de la zona escolar'}.`} action={<span className="page-chip"><Icon name="calendar" size={16}/> Octubre 2026</span>}/>
    <DemoNotice />
    <div className="stats-grid"><StatCard icon="bell" number="03" label="Avisos publicados" foot="Comunicados de ejemplo"/><StatCard icon="list" number="04" label="Solicitudes registradas" foot="Actividades simuladas"/><StatCard icon="clock" number="01" label="Pendientes" foot="Requiere atención"/><StatCard icon="check" number="01" label="Entregas aceptadas" foot="Estado de muestra"/></div>
    <div className="dashboard-columns"><section className="surface-card activity-card"><div className="card-header"><div><div className="card-kicker">ACTIVIDAD RECIENTE</div><h2>Solicitudes del plantel</h2></div><button className="link-button" onClick={()=>goTo('solicitudes')}>Ver todas <Icon name="arrow" size={16}/></button></div><div className="activity-list">{solicitudes.slice(0,3).map(item=><div className="activity-row" key={item.id}><div className="activity-icon"><Icon name="file" size={18}/></div><div className="activity-main"><strong>{item.titulo}</strong><span>{item.id} · Fecha límite: {item.vence}</span></div><Status estado={item.estado}/></div>)}</div></section>
      <section className="surface-card quick-card"><div className="card-kicker">ACCESOS DIRECTOS</div><h2>¿Qué deseas consultar?</h2><p>Accede a las secciones más utilizadas de la plataforma.</p><button className="quick-link" onClick={()=>goTo('avisos')}><span className="quick-icon"><Icon name="bell"/></span><span><strong>Consultar avisos</strong><small>Comunicados y recordatorios</small></span><Icon name="chevron" size={18}/></button><button className="quick-link" onClick={()=>goTo('solicitudes')}><span className="quick-icon"><Icon name="list"/></span><span><strong>Ver solicitudes</strong><small>Fechas límite y seguimiento</small></span><Icon name="chevron" size={18}/></button><button className="quick-link" onClick={()=>goTo('evidencias')}><span className="quick-icon"><Icon name="upload"/></span><span><strong>Revisar evidencias</strong><small>Ejemplo de entrega y revisión</small></span><Icon name="chevron" size={18}/></button></section></div>
    <div className="explain-strip"><Icon name="shield" size={20}/><p><strong>Diseño por perfiles.</strong> Esta vista es una simulación visual de los accesos de {nombre.toLowerCase()}. Los permisos reales se implementarán en una etapa posterior.</p></div>
  </>;
}

function Avisos({ rol }) {
  const puedePublicar = rol!=='directora';
  return <>
    <Heading eyebrow="COMUNICACIÓN" title="Avisos y comunicados" description="Información publicada para consulta de los planteles de la zona escolar." action={<span className="page-chip"><Icon name="bell" size={16}/> {avisos.length} avisos de ejemplo</span>}/>
    <DemoNotice/>
    <div className="filter-row"><div className="search-visual"><Icon name="search" size={18}/><span>Buscar comunicados</span><span className="search-visual-note">Diseño ilustrativo</span></div>{puedePublicar && <span className="disabled-action"><Icon name="file" size={17}/> Nuevo aviso · Próxima etapa</span>}</div>
    <div className="notices-list">{avisos.map((aviso,i)=><article className="surface-card notice-card" key={aviso.id}><div className="notice-left"><div className="notice-icon"><Icon name={i===1?'clock':'bell'} size={22}/></div><div className="notice-content"><div className="notice-meta"><span className="type-badge">{aviso.tipo}</span><span>{aviso.fecha}</span><span className="meta-dot">·</span><span>{aviso.publico}</span></div><h2>{aviso.titulo}</h2><p>{aviso.texto}</p><div className="notice-code">Clave de demostración: {aviso.id}</div></div></div><span className="notice-end"><Icon name="chevron" size={20}/></span></article>)}</div>
    <p className="under-note">Los comunicados mostrados son ficticios. Esta sección no permite publicar ni modificar avisos.</p>
  </>;
}

function Solicitudes() {
  const [filter,setFilter] = useState('Todas');
  const lista = filter==='Todas' ? solicitudes : solicitudes.filter(x=>x.estado===filter);
  return <>
    <Heading eyebrow="SEGUIMIENTO" title="Solicitudes" description="Consulta de solicitudes, fechas límite y estados de entrega. Los datos son ilustrativos." action={<span className="page-chip"><Icon name="list" size={16}/> 4 solicitudes</span>}/>
    <DemoNotice />
    <div className="surface-card requests-card"><div className="requests-intro"><div><h2>Listado de solicitudes</h2><p>Selecciona un estado para visualizar el ejemplo de filtrado local.</p></div><span className="requests-count">{lista.length} resultados</span></div>
      <div className="filter-pills" role="group" aria-label="Filtrar por estado">{['Todas','Pendiente','Entregado','Corrección','Aceptado'].map(x=><button key={x} onClick={()=>setFilter(x)} className={`filter-pill ${filter===x?'selected':''}`} aria-pressed={filter===x}>{x}</button>)}</div>
      <div className="table-wrap"><table className="request-table"><thead><tr><th>Solicitud</th><th>Área</th><th>Fecha límite</th><th>Estado</th><th></th></tr></thead><tbody>{lista.map(item=><tr key={item.id}><td><strong>{item.titulo}</strong><span>{item.id} · {item.detalle}</span></td><td>{item.area}</td><td>{item.vence}</td><td><Status estado={item.estado}/></td><td><button className="table-view" onClick={()=>goTo('evidencias')} aria-label={`Ver ejemplo de evidencia para ${item.titulo}`}><Icon name="chevron" size={19}/></button></td></tr>)}</tbody></table>{!lista.length && <div className="empty">No hay registros de ejemplo con este estado.</div>}</div>
    </div><div className="explain-strip"><Icon name="info" size={20}/><p>El botón de cada solicitud abre una pantalla ilustrativa de evidencias. Las fechas, estados y responsables no representan solicitudes reales.</p></div>
  </>;
}

function Evidencias({ rol }) {
  return <>
    <Heading eyebrow="DOCUMENTACIÓN" title="Entrega y revisión de evidencias" description="Propuesta de pantalla para consultar los detalles de una solicitud y sus archivos asociados." action={<span className="page-chip"><Icon name="file" size={16}/> P-07 · Prototipo</span>}/>
    <DemoNotice />
    <div className="evidence-grid"><section className="surface-card evidence-main"><div className="card-kicker">SOLICITUD DE EJEMPLO · SOL-001</div><h2>Planeación mensual</h2><p className="evidence-description">Se presenta el diseño de una solicitud que requeriría adjuntar un documento en formato digital.</p><div className="detail-grid"><div><span>Fecha límite</span><strong>20 de octubre de 2026</strong></div><div><span>Plantel</span><strong>Plantel de demostración</strong></div><div><span>Estado</span><Status estado="Pendiente"/></div><div><span>Tipo de archivo</span><strong>PDF, Word o imagen</strong></div></div>
      <div className="upload-mock"><div className="upload-mock-icon"><Icon name="upload" size={27}/></div><strong>Área ilustrativa para adjuntar un archivo</strong><p>En la versión funcional, aquí se podrán seleccionar documentos desde la computadora o el teléfono.</p><button className="btn btn-outline" type="button" disabled><Icon name="folder" size={18}/> Seleccionar archivo (no disponible)</button></div>
      <div className="review-step"><Icon name="info" size={19}/><span>Esta maqueta no permite subir, enviar ni guardar documentos.</span></div>
      </section><aside className="surface-card evidence-side"><div className="card-kicker">FLUJO PROPUESTO</div><h2>Etapas de una entrega</h2><div className="steps"><div className="step"><span className="step-num">1</span><div><strong>Pendiente</strong><small>El plantel consulta la solicitud.</small></div></div><div className="step"><span className="step-num">2</span><div><strong>Entregado</strong><small>Se adjunta un documento.</small></div></div><div className="step"><span className="step-num">3</span><div><strong>Revisión</strong><small>El perfil autorizado verifica el archivo.</small></div></div><div className="step"><span className="step-num">4</span><div><strong>Aceptado o corrección</strong><small>Se registra el resultado.</small></div></div></div><div className="side-note"><Icon name="shield" size={19}/><p>Vista actual: <strong>{perfiles[rol].nombre}</strong>. La separación real de permisos será implementada posteriormente.</p></div></aside></div>
  </>;
}

export default function App() {
  const [route,setRoute] = useState(getCurrentRoute);
  const [rol,setRol] = useState('directora');
  useEffect(()=>{ const handler = ()=>setRoute(getCurrentRoute()); window.addEventListener('hashchange',handler); return ()=>window.removeEventListener('hashchange',handler); },[]);
  if (route==='acceso') return <LoginPage rol={rol} setRol={setRol}/>;
  return <AppShell route={route} rol={rol} setRol={setRol}>
    {route==='panel'&&<Dashboard rol={rol}/>}
    {route==='avisos'&&<Avisos rol={rol}/>}
    {route==='solicitudes'&&<Solicitudes/>}
    {route==='evidencias'&&<Evidencias rol={rol}/>}
  </AppShell>;
}
